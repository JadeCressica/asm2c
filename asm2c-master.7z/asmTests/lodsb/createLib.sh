rm *.o;make OBJECTS=lodsb.o TARGET_NAME=lodsb
