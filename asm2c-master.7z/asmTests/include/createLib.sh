rm *.o;make OBJECTS=include.o TARGET_NAME=include
