rm *.o;make OBJECTS=data.o TARGET_NAME=data
