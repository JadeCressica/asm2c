rm *.o;make test INCLUDEMAIN=1 DEBUG=1 OBJECTS=data.o TARGET_NAME=data
