rm *.o;make OBJECTS=cmp.o TARGET_NAME=cmp
