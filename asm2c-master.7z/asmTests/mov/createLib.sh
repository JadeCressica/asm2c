rm *.o;make OBJECTS=mov.o TARGET_NAME=mov
