rm *.o;make OBJECTS=rol.o TARGET_NAME=rol
