rm *.o;make test TEST=1 DEBUG=1 OBJECTS=chars8b.o TARGET_NAME=chars8b
