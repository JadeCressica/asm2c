rm *.o;make OBJECTS=jxx.o TARGET_NAME=jxx
