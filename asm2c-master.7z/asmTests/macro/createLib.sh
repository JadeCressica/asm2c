rm *.o;make OBJECTS=macro.o TARGET_NAME=macro
