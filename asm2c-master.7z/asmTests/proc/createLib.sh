rm *.o;make OBJECTS=proc.o TARGET_NAME=proc
