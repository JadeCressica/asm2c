rm *.o;make test INCLUDEMAIN=1 DEBUG=1 OBJECTS=datadup.o TARGET_NAME=datadup
