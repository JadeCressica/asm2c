rm *.o;make OBJECTS=datadup.o TARGET_NAME=datadup
