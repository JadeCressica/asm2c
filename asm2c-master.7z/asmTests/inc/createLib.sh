rm *.o;make OBJECTS=inc.o TARGET_NAME=inc
