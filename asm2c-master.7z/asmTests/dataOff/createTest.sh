rm *.o;make test INCLUDEMAIN=1 DEBUG=1 OBJECTS=dataOff.o TARGET_NAME=dataOff
