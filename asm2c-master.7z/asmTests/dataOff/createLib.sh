rm *.o;make OBJECTS=dataOff.o TARGET_NAME=dataOff
