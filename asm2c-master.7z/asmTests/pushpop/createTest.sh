rm *.o;make test INCLUDEMAIN=1 DEBUG=1 OBJECTS=pushpop.o TARGET_NAME=pushpop
