rm *.o;make OBJECTS=loop.o TARGET_NAME=loop
